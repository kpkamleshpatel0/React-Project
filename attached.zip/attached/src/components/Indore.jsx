import React from 'react'

export default function Indore() {
  return (
    <div>
      Indore
    </div>
  )
}
