const Platfrom1=()=>{
    return(
        <>
        <h5 style={{color:'blue'}}> Train B/W Noida to bhopal: Platform No 1 </h5>
        <p style={{color:'red'}}><b>Train name are - </b></p>
        <ol>
            <li m-2 style={{color:'green'}}>07189/Hazur Sahib Nanded - Erode Special Fare Special</li>
            <li style={{color:'green'}}>07190/Erode - Hazur Sahib Nanded Special Fare Special</li>
            <li style={{color:'green'}}>010712 -KAMAYANI EXP SPL</li>
            <li style={{color:'green'}}>#02912 - HWH INDB SPL</li>
            <li style={{color:'green'}}>#09314 - PNBE INDB SPL</li>
            
        </ol>
        <img src="https://www.fabhotels.com/blog/wp-content/uploads/2020/02/How-to-Reach-Noida.jpg:cf-webp:w-1400:h-500" alt="photo" height={350} width={600}/>
        </>
    )
}
export default Platfrom1;