const NotFound=()=>{
    return(
        <>
        <p>Page not found error 404 !</p>
        </>
    )
}
export default NotFound;