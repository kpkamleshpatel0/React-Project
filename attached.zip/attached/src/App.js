import { BrowserRouter as Router,Routes,Route} from "react-router-dom";
import Nav from "./components/Nav";
import Home from "./components/Home";
import About from "./components/About";
import Gallery from "./components/Gallery";
import Contact from "./components/Contact";
import NotFound from "./components/NotFound";
import Category from "./components/Category";
import Noida from "./components/Noida";
import Mumbai from "./components/Mumbai";
import Indore from "./components/Indore";
import Gurugram from "./components/Gurugram";
import Chip from "./components/Chip";
import Platfrom1 from "./components/Platform1";

const App=()=>{
  return(
<main style={{backgroundColor:'lightblue', backgroundImage:'initial'}}>
  <Router>
    <Nav/>
    <section className="contianer">
      <Routes>
        <Route path="" element={<Home/>}/>
        <Route path="about" element={<About/>}/>
        <Route path="gallery" element={<Gallery/>}/>
        <Route path="contact" element={<Contact/>}>
          <Route path="noida" element={<Noida/>}>
            <Route path="r1" element={<Chip/>}>
              <Route path="a1" element={<Platfrom1/>}/>
            </Route>
          </Route>
          <Route path="mumbai" element={<Mumbai/>}/>
          <Route path="gurugram" element={<Gurugram/>}/>
          <Route path="indore" element={<Indore/>}/>
        </Route>
        <Route path='category/:cname' element={<Category/>}/>
        <Route path="*" element={<NotFound/>}/>
      </Routes>

    </section>
  </Router>
  
</main>
  )
  
  
}
export default App;